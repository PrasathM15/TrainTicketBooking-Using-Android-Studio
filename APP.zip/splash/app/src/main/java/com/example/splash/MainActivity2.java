package com.example.splash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import com.example.splash.MainActivity3;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;


public class MainActivity2 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent intent = getIntent();
        int quantity = intent.getIntExtra("quantity", 1); // Default quantity is 1

        TextView quantityTextView = findViewById(R.id.quantityTextView);
        TextView quantityTextView1 = findViewById(R.id.itemPriceTextView);
        quantityTextView.setText(quantity + " ticket");
        quantityTextView1.setText("Price: ₹" + quantity*5 +".00");

        // Get current date
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
        String currentDate = dateFormat.format(calendar.getTime());

        // Set current date to TextView
        TextView currentDateTextView = findViewById(R.id.currentDateTextView);
        currentDateTextView.setText("" + currentDate);

        // Get current time
        Calendar calendar1 = Calendar.getInstance();
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String currentTime = timeFormat.format(calendar1.getTime());

        // Set current time to TextView
        TextView currentTimeTextView = findViewById(R.id.currentTimeTextView);
        currentTimeTextView.setText("" + currentTime);


    }
    public void goToNextPage(View view) {
        Intent intent = new Intent(this, MainActivity3.class);
        startActivity(intent);
    }

}
