package com.example.splash;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import androidx.appcompat.app.AppCompatActivity;

import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button button;
    private static final String[] ITEMS = {
            // Stations between Sullurupeta and Chennai Central
            "Sullurupeta", "Tada", "Arambakkam", "Elevur", "Gummidipundi",
            "Kavaraipettai", "Ponneri", "Anuppambattu", "Minjur", "Nandiyampakkam",
            "Attipattu", "Attipatti Podu -NGR H", "Ennore", "Kathivakkam",
            "Wimco Nagar", "Tiruvottiyur", "VOC Nagar", "Tondiarpet",
            "Korukkupet Junction", "Basin Bridge Junction", "Chennai Central",
            // Stations between Chengalpattu and Chennai Beach
            "Chengalpattu", "Paranur", "Singaperumal-Koil", "Maraimalai Nagar-Kamarajar",
            "Kattangulathur", "Potheri", "Guduvancheri", "Urapakkam", "Vandalur",
            "Perungalattur", "Tambaram", "Tambaram Sanatorium", "Chrompet", "Pallavaram",
            "Tirusulam", "Minambakkam", "Palavanthangal", "St. Thomas Mount", "Guindy",
            "Saidapet", "Mambalam", "Kodambakkam", "Nungambakkam", "Chennai Chetpat",
            "Chennai Egmore", "Chennai Park",
            // Stations between Velachery and Chennai Beach
            "Velachery", "Perungudi", "Taramani", "Tiruvanmiyur", "Indra Nagar",
            "Kasturba Nagar", "Kotturpuram", "Greenways Road", "Mandaveli", "Thirumayilai",
            "Mundakakanni Amman Koil", "Lighthouse", "Tiruvallikeni", "Chepauk",
            "Chintadripet", "Chennai Park Town", "Chennai Fort", "Chennai Beach"
    };

    private static final String[] ITEMS1 = {
            // Stations between Sullurupeta and Chennai Central
            "Sullurupeta", "Tada", "Arambakkam", "Elevur", "Gummidipundi",
            "Kavaraipettai", "Ponneri", "Anuppambattu", "Minjur", "Nandiyampakkam",
            "Attipattu", "Attipatti Podu -NGR H", "Ennore", "Kathivakkam",
            "Wimco Nagar", "Tiruvottiyur", "VOC Nagar", "Tondiarpet",
            "Korukkupet Junction", "Basin Bridge Junction", "Chennai Central",
            // Stations between Chengalpattu and Chennai Beach
            "Chengalpattu", "Paranur", "Singaperumal-Koil", "Maraimalai Nagar-Kamarajar",
            "Kattangulathur", "Potheri", "Guduvancheri", "Urapakkam", "Vandalur",
            "Perungalattur", "Tambaram", "Tambaram Sanatorium", "Chrompet", "Pallavaram",
            "Tirusulam", "Minambakkam", "Palavanthangal", "St. Thomas Mount", "Guindy",
            "Saidapet", "Mambalam", "Kodambakkam", "Nungambakkam", "Chennai Chetpat",
            "Chennai Egmore", "Chennai Park",
            // Stations between Velachery and Chennai Beach
            "Velachery", "Perungudi", "Taramani", "Tiruvanmiyur", "Indra Nagar",
            "Kasturba Nagar", "Kotturpuram", "Greenways Road", "Mandaveli", "Thirumayilai",
            "Mundakakanni Amman Koil", "Lighthouse", "Tiruvallikeni", "Chepauk",
            "Chintadripet", "Chennai Park Town", "Chennai Fort", "Chennai Beach"
    };

    private EditText quantityEditText;
    private Button incrementButton, decrementButton, nextButton;
    private AutoCompleteTextView autoCompleteTextView1;
    private AutoCompleteTextView autoCompleteTextView2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AutoCompleteTextView autoCompleteTextView1 = findViewById(R.id.et1);
        AutoCompleteTextView autoCompleteTextView2 = findViewById(R.id.et2);

        quantityEditText = findViewById(R.id.quantityEditText);
        incrementButton = findViewById(R.id.incrementButton);
        decrementButton = findViewById(R.id.decrementButton);
        nextButton = findViewById(R.id.nextbutton);

        incrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incrementQuantity();
            }
        });

        decrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrementQuantity();
            }
        });

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToNextActivity();
            }
        });




        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, ITEMS);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this,
                android.R.layout.simple_dropdown_item_1line, ITEMS1);
        autoCompleteTextView1.setAdapter(adapter1);
        autoCompleteTextView2.setAdapter(adapter2);
    }
    private void navigateToNextActivity() {
        int quantity = Integer.parseInt(quantityEditText.getText().toString());
        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
        intent.putExtra("quantity", quantity);
        startActivity(intent);
    }
    private void incrementQuantity() {
        // Increment quantity
        int quantity = Integer.parseInt(quantityEditText.getText().toString());
        quantity++;
        quantityEditText.setText(String.valueOf(quantity));
    }

    private void decrementQuantity() {
        // Decrement quantity
        int quantity = Integer.parseInt(quantityEditText.getText().toString());
        if (quantity > 1) {
            quantity--;
            quantityEditText.setText(String.valueOf(quantity));
        } else {
            Toast.makeText(this, "Quantity cannot be less than 1", Toast.LENGTH_SHORT).show();
        }
    }
}